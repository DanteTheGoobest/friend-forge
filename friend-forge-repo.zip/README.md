# Friend (Forge port)

Java port of the Friend horror add-on for Forge 1.20.1 and 1.21.1 (GeckoLib).
Pushing triggers the Actions build; jars appear under the run Artifacts.

Test commands (op): /friend watch|stalk|chase|vanish
