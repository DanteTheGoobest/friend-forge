package dev.dante.friend;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/** Mimic spawner + presence (phantom sounds/hits) + fake jumpscares. Port of mimic.js / main.js presence. */
public class Extras {
    private static Extras self;
    public Extras() { self = this; }
    public static void forceMimic(ServerPlayer p, boolean follower) { if (self != null) self.spawnMimicNow(p.serverLevel(), p, follower); }
    private final Random rng = new Random();
    private final Map<UUID, Long> nextMimic = new HashMap<>();
    private final Map<UUID, long[]> presence = new HashMap<>(); // sound, hit, scare (game ticks)
    private final List<Fake> fakes = new ArrayList<>();
    private final java.util.Set<UUID> scareBusy = new java.util.HashSet<>();

    // ---- rare sets: name, skin
    private static final Object[][] RARE = {
            {"DanteZeGOOB", 8}, {"Reddism", 9}, {"DoubleRockstar", 10}, {"Iloann", 11}, {"Blou Apie1177", 12}};
    private static final String[] W1 = {"toast", "gravel", "moth", "pickle", "waffle", "static", "bagel", "turnip", "soggy", "velvet", "crumb", "limp", "pebble", "nacho", "ferret", "lint", "marsh", "jelly", "mango", "gremlin", "thistle", "pudding", "cricket", "ember", "kettle", "mold", "noodle", "plum", "rust", "sock", "tin", "wobble", "yarn", "zinc", "oat", "hush", "dusk", "fig", "haze", "kelp"};
    private static final String[] W2 = {"goblin", "lord", "enjoyer", "dealer", "bandit", "wizard", "farmer", "gremlin", "merchant", "mage", "pilot", "ranger", "tamer", "witch", "knight", "baker", "cat", "dog", "frog", "bean", "cheese", "boy", "girl", "man", "guy", "king", "bro", "dude", "clown", "monk", "hermit", "sage"};
    private static final String[] FIRST = {"Jaxon", "Mateo", "Priya", "Tobias", "Hana", "Declan", "Ayla", "Rohan", "Marlow", "Odette", "Callum", "Ines", "Bram", "Sakura", "Theo", "Lucia", "Eamon", "Wren", "Dmitri", "Kiana", "Rhys", "Anya", "Felix", "Maeve", "Idris", "Cleo", "Soren", "Tamsin", "Hugo", "Nadia"};
    private static final String[] TAIL = {"gaming", "yt", "plays", "irl", "mc", "_", "_xd", "_official", "123", "69", "420", "07", "_01", "x", "tv"};

    private <T> T pick(T[] a) { return a[rng.nextInt(a.length)]; }
    private int ri(int a, int b) { return a + rng.nextInt(b - a + 1); }
    private static String cap(String s) { return Character.toUpperCase(s.charAt(0)) + s.substring(1); }
    private String noise(int n) { StringBuilder sb = new StringBuilder(); for (int i = 0; i < n; i++) sb.append((char) ('a' + rng.nextInt(26))); return sb.toString(); }
    private String leet(String w) {
        StringBuilder sb = new StringBuilder();
        for (char c : w.toCharArray()) {
            String r = switch (c) { case 'a' -> "4"; case 'e' -> "3"; case 'i' -> "1"; case 'o' -> "0"; case 's' -> "5"; default -> null; };
            sb.append(r != null && rng.nextBoolean() ? r : String.valueOf(c));
        }
        return sb.toString();
    }

    private String randomUsername() {
        String a = pick(W1), b = pick(W2), f = pick(FIRST);
        return switch (rng.nextInt(15)) {
            case 0 -> a + b;
            case 1 -> cap(a) + cap(b) + ri(1, 999);
            case 2 -> a + "_" + b;
            case 3 -> f + ri(10, 9999);
            case 4 -> f.toLowerCase() + "." + b;
            case 5 -> cap(a) + " " + cap(b) + " " + ri(1000, 9999);
            case 6 -> leet(a + b);
            case 7 -> noise(ri(5, 8)) + ri(1, 99);
            case 8 -> "i" + a + b + "i".repeat(ri(0, 2));
            case 9 -> f + pick(TAIL);
            case 10 -> "The" + cap(a);
            case 11 -> a + ri(2003, 2013);
            case 12 -> "not_" + f.toLowerCase();
            case 13 -> cap(a) + cap(b) + "_" + noise(2).toUpperCase();
            default -> f.substring(0, ri(3, 4)) + cap(a).substring(0, ri(2, 3)) + ri(0, 99);
        };
    }

    private String typo(String n) {
        if (n.length() < 3) return n;
        int i = ri(1, n.length() - 2);
        return switch (rng.nextInt(4)) {
            case 0 -> n.substring(0, i) + n.charAt(i + 1) + n.charAt(i) + n.substring(i + 2);
            case 1 -> n.substring(0, i) + n.charAt(i) + n.substring(i);
            case 2 -> n.substring(0, i) + n.substring(i + 1);
            default -> { char c = n.charAt(i); yield n.substring(0, i) + (Character.isLowerCase(c) ? Character.toUpperCase(c) : Character.toLowerCase(c)) + n.substring(i + 1); }
        };
    }

    // ------------------------------------------------------------------ tick
    private static int tier(ServerLevel l) {
        int day = (int) ((l.getDayTime() / 24000L) % 6);
        return day >= 5 ? 2 : day >= 2 ? 1 : 0;
    }

    @SubscribeEvent
    public void tick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        ServerLevel lvl = e.getServer().overworld();
        long now = lvl.getGameTime();
        tickFakes(lvl);
        for (Iterator<Later> it = later.iterator(); it.hasNext(); ) { Later s = it.next(); if (now >= s.due) { it.remove(); s.r.run(); } }
        if (now % 4 != 0) return;
        int t = tier(lvl);
        boolean friendOut = FriendDirector.INSTANCE.friendActive();
        for (ServerPlayer p : lvl.players()) {
            if (p.isSpectator() || !p.isAlive()) continue;
            // ---------------- Mimic spawner
            if (!nextMimic.containsKey(p.getUUID())) nextMimic.put(p.getUUID(), now + (long) (20 * (ri(330, 760) * 0.5)));
            if (now >= nextMimic.get(p.getUUID()) && !friendOut) {
                int[] lo = {330, 220, 130}, hi = {760, 520, 320};
                nextMimic.put(p.getUUID(), now + 20L * ri(lo[t], hi[t]));
                spawnMimic(lvl, p);
            }
            // ---------------- presence
            if (friendOut || scareBusy.contains(p.getUUID())) continue;
            if (hasMimicNear(lvl, p)) continue;
            long[] pr = presence.computeIfAbsent(p.getUUID(), k -> new long[]{now + 20L * ri(60, 150), now + 20L * ri(120, 300), now + 20L * ri(120, 300)});
            int[] sLo = {150, 70, 35}, sHi = {330, 170, 90}, hLo = {300, 240, 120}, hHi = {600, 520, 260}, cLo = {300, 200, 120}, cHi = {660, 440, 260};
            if (now >= pr[0]) { pr[0] = now + 20L * ri(sLo[t], sHi[t]); if (rng.nextBoolean()) farCall(lvl, p); else footsteps(lvl, p); }
            if (now >= pr[1]) { pr[1] = now + 20L * ri(hLo[t], hHi[t]); phantomHit(lvl, p); }
            if (now >= pr[2]) {
                pr[2] = now + 20L * ri(cLo[t], cHi[t]);
                boolean ok = rng.nextDouble() < 0.5 && scareDoor(lvl, p);
                if (!ok) scareAppear(lvl, p);
            }
        }
    }

    private boolean hasMimicNear(ServerLevel l, ServerPlayer p) {
        return !l.getEntitiesOfClass(MimicEntity.class, p.getBoundingBox().inflate(120)).isEmpty();
    }

    // ------------------------------------------------------------------ echo what players say
    @SubscribeEvent
    public void onChat(ServerChatEvent e) {
        ServerPlayer sp = e.getPlayer();
        if (!(sp.level() instanceof ServerLevel l)) return;
        List<MimicEntity> ms = l.getEntitiesOfClass(MimicEntity.class, sp.getBoundingBox().inflate(80));
        if (ms.isEmpty() || rng.nextDouble() > 0.6) return;
        MimicEntity m = ms.get(rng.nextInt(ms.size()));
        String t = e.getRawText();
        if (t == null || t.isEmpty()) return;
        final String said = rng.nextBoolean() ? typo(t) : t;
        later.add(new Later(l.getGameTime() + 25 + rng.nextInt(40), () -> { if (!m.isRemoved()) m.sayPublic(said); }));
    }

    // ------------------------------------------------------------------ mimic
    private void spawnMimic(ServerLevel lvl, ServerPlayer p) {
        if (hasMimicNear(lvl, p)) return;
        spawnMimicNow(lvl, p, rng.nextDouble() < 0.45);
    }

    private void spawnMimicNow(ServerLevel lvl, ServerPlayer p, boolean follower) {
        Vec3 pos = ground(lvl, p, follower ? 14 : 20, follower ? 20 : 30);
        if (pos == null) return;
        String name; int skin; boolean rare = false;
        if (rng.nextDouble() < 0.06) { Object[] r = RARE[rng.nextInt(RARE.length)]; name = (String) r[0]; skin = (Integer) r[1]; rare = true; }
        else {
            List<ServerPlayer> others = new ArrayList<>();
            for (ServerPlayer q : lvl.players()) if (q != p) others.add(q);
            name = !others.isEmpty() && rng.nextDouble() < 0.35 ? others.get(rng.nextInt(others.size())).getGameProfile().getName() : randomUsername();
            if (rng.nextDouble() < 0.5) name = typo(name);
            skin = rng.nextInt(7);
        }
        MimicEntity m = (follower ? FriendMod.FOLLOWER : FriendMod.MIMIC).get().create(lvl);
        if (m == null) return;
        m.moveTo(pos.x, pos.y, pos.z, rng.nextFloat() * 360f, 0f);
        m.setIdentity(name, skin, rare, null);
        lvl.addFreshEntity(m);
        if (rng.nextDouble() < 0.7)
            lvl.getServer().getPlayerList().broadcastSystemMessage(
                    Component.translatable("multiplayer.player.joined", Component.literal(name)).withStyle(ChatFormatting.YELLOW), false);
    }

    private Vec3 ground(ServerLevel lvl, ServerPlayer p, double min, double max) {
        for (int i = 0; i < 24; i++) {
            double a = rng.nextDouble() * Math.PI * 2, r = min + rng.nextDouble() * (max - min);
            int x = (int) (p.getX() + Math.cos(a) * r), z = (int) (p.getZ() + Math.sin(a) * r);
            if (!lvl.hasChunkAt(new BlockPos(x, 64, z))) continue;
            int y = lvl.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            BlockPos bp = new BlockPos(x, y, z);
            if (!lvl.getBlockState(bp.below()).isSolid() || !lvl.getFluidState(bp).isEmpty()) continue;
            return new Vec3(x + 0.5, y, z + 0.5);
        }
        return null;
    }

    // ------------------------------------------------------------------ presence
    private void at(ServerLevel l, Vec3 v, SoundEvent s, float vol, float pitch) {
        l.playSound(null, v.x, v.y, v.z, s, SoundSource.HOSTILE, vol, pitch);
    }

    private void farCall(ServerLevel l, ServerPlayer p) {
        double a = rng.nextDouble() * Math.PI * 2, d = 22 + rng.nextDouble() * 22;
        Vec3 loc = new Vec3(p.getX() + Math.cos(a) * d, p.getY(), p.getZ() + Math.sin(a) * d);
        SoundEvent[] s = {SoundEvents.WARDEN_LISTENING, SoundEvents.ENDERMAN_STARE, SoundEvents.GHAST_AMBIENT, SoundEvents.WARDEN_NEARBY_CLOSE};
        at(l, loc, pick(s), 4f, 0.6f);
    }

    private void footsteps(ServerLevel l, ServerPlayer p) {
        double yaw = Math.toRadians(p.getYRot());
        double bx = -Math.sin(yaw) * -1, bz = Math.cos(yaw) * -1; // behind
        final double ang = Math.atan2(bz, bx) + (rng.nextDouble() - 0.5) * 1.2;
        int steps = 5 + rng.nextInt(3);
        for (int i = 0; i < steps; i++) stepAt(l, p, ang, i, i * 9);
    }

    private static class Later { long due; Runnable r; Later(long d, Runnable r) { due = d; this.r = r; } }
    private final List<Later> later = new ArrayList<>();
    private void stepAt(ServerLevel l, ServerPlayer p, double ang, int i, int delay) {
        later.add(new Later(l.getGameTime() + delay, () -> {
            if (!p.isAlive()) return;
            double d = 10 - i * 1.3;
            at(l, new Vec3(p.getX() + Math.cos(ang) * d, p.getY(), p.getZ() + Math.sin(ang) * d), SoundEvents.ZOMBIE_STEP, 3f, 0.55f);
        }));
    }

    private void phantomHit(ServerLevel l, ServerPlayer p) {
        double a = rng.nextDouble() * Math.PI * 2;
        l.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.PLAYER_HURT, SoundSource.PLAYERS, 1f, 0.8f);
        at(l, new Vec3(p.getX() + Math.cos(a), p.getY() + 1, p.getZ() + Math.sin(a)), SoundEvents.WARDEN_ATTACK_IMPACT, 1.5f, 1.2f);
        p.push(-Math.cos(a) * 0.5, 0.2, -Math.sin(a) * 0.5);
        p.hurtMarked = true;
    }

    // ------------------------------------------------------------------ fake jumpscares (never hurt)
    private static class Fake {
        FriendEntity e; ServerPlayer p; int ticks; boolean rush; double speed;
    }

    private FriendEntity makeFake(ServerLevel l, ServerPlayer p, Vec3 at) {
        FriendEntity f = FriendMod.FRIEND.get().create(l);
        if (f == null) return null;
        f.moveTo(at.x, at.y, at.z, 0, 0);
        f.setPhase(FriendEntity.CHASE);
        f.addTag("friend_fake");
        f.frozen = true;
        f.setTargetPlayer(p.getUUID());
        l.addFreshEntity(f);
        return f;
    }

    private void face(FriendEntity f, ServerPlayer p) {
        double dx = p.getX() - f.getX(), dz = p.getZ() - f.getZ();
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        f.setYRot(yaw); f.setYHeadRot(yaw); f.yBodyRot = yaw;
    }

    private boolean roomFor(ServerLevel l, BlockPos p) {
        for (int i = 0; i < 3; i++) { BlockState s = l.getBlockState(p.above(i)); if (!s.getCollisionShape(l, p.above(i)).isEmpty()) return false; }
        return l.getBlockState(p.below()).isSolid();
    }

    private boolean scareAppear(ServerLevel l, ServerPlayer p) {
        Vec3 look = p.getViewVector(1f); Vec3 flat = new Vec3(look.x, 0, look.z).normalize();
        Vec3 spot = new Vec3(p.getX() + flat.x * 3.6, p.getY(), p.getZ() + flat.z * 3.6);
        if (!roomFor(l, BlockPos.containing(spot))) return false;
        FriendEntity f = makeFake(l, p, spot);
        if (f == null) return false;
        face(f, p);
        f.setAction(FriendEntity.ACT_ROAR);
        p.playNotifySound(FriendMod.ROAR.get(), SoundSource.MASTER, 0.7f, 1.15f);
        Fake fk = new Fake(); fk.e = f; fk.p = p; fk.ticks = 7; fk.rush = false;
        fakes.add(fk); scareBusy.add(p.getUUID());
        return true;
    }

    private boolean scareDoor(ServerLevel l, ServerPlayer p) {
        BlockPos pp = p.blockPosition();
        Vec3 view = p.getViewVector(1f);
        List<BlockPos> found = new ArrayList<>();
        for (int dx = -15; dx <= 15; dx++) for (int dz = -15; dz <= 15; dz++) for (int dy = -1; dy <= 1; dy++) {
            double d = Math.hypot(dx, dz);
            if (d < 5 || d > 15) continue;
            BlockPos bp = pp.offset(dx, dy, dz);
            BlockState s = l.getBlockState(bp);
            if (!s.is(BlockTags.WOODEN_DOORS)) continue;
            if (s.getValue(DoorBlock.HALF) != net.minecraft.world.level.block.state.properties.DoubleBlockHalf.LOWER) continue;
            if (s.getValue(DoorBlock.OPEN)) continue;
            Vec3 dir = new Vec3(dx, dy + 1, dz).normalize();
            if (view.dot(dir) < 0.35) continue;
            found.add(bp);
        }
        if (found.isEmpty()) return false;
        BlockPos door = found.get(rng.nextInt(found.size()));
        Vec3 away = new Vec3(door.getX() + 0.5 - p.getX(), 0, door.getZ() + 0.5 - p.getZ()).normalize();
        Vec3 spot = new Vec3(door.getX() + 0.5 + away.x * 1.5, door.getY(), door.getZ() + 0.5 + away.z * 1.5);
        if (!roomFor(l, BlockPos.containing(spot))) return false;
        BlockState s = l.getBlockState(door);
        ((DoorBlock) s.getBlock()).setOpen(null, l, s, door, true);
        l.playSound(null, door, SoundEvents.WOODEN_DOOR_OPEN, SoundSource.BLOCKS, 1.4f, 0.8f);
        FriendEntity f = makeFake(l, p, spot);
        if (f == null) return false;
        face(f, p);
        p.playNotifySound(FriendMod.ROAR.get(), SoundSource.MASTER, 0.85f, 1f);
        Fake fk = new Fake(); fk.e = f; fk.p = p; fk.ticks = 22; fk.rush = true; fk.speed = 0.42;
        fakes.add(fk); scareBusy.add(p.getUUID());
        return true;
    }

    private void tickFakes(ServerLevel l) {
        for (Iterator<Fake> it = fakes.iterator(); it.hasNext(); ) {
            Fake fk = it.next();
            if (fk.e == null || fk.e.isRemoved() || !fk.p.isAlive()) { it.remove(); scareBusy.remove(fk.p.getUUID()); continue; }
            face(fk.e, fk.p);
            boolean end = false;
            if (!fk.rush) { if (--fk.ticks <= 0) end = true; }
            else {
                if (fk.ticks > 0) { fk.ticks--; fk.e.setAction(FriendEntity.ACT_ROAR); }
                else {
                    fk.e.setAction(FriendEntity.ACT_NONE);
                    Vec3 d = new Vec3(fk.p.getX() - fk.e.getX(), 0, fk.p.getZ() - fk.e.getZ());
                    if (d.length() < 2.6) end = true;
                    else { Vec3 n = d.normalize().scale(fk.speed); fk.e.setPos(fk.e.getX() + n.x, fk.e.getY(), fk.e.getZ() + n.z); }
                }
            }
            if (end) {
                l.sendParticles(ParticleTypes.POOF, fk.e.getX(), fk.e.getY() + 1.3, fk.e.getZ(), 30, 0.4, 0.8, 0.4, 0.03);
                fk.e.discard();
                fk.p.playNotifySound(SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 0.9f, 0.7f);
                fk.p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 50, 0, false, false));
                it.remove(); scareBusy.remove(fk.p.getUUID());
            }
        }
    }
}
