package dev.dante.friend.client;

import dev.dante.friend.Compat;
import dev.dante.friend.MimicEntity;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class MimicRenderer extends HumanoidMobRenderer<MimicEntity, PlayerModel<MimicEntity>> {
    public MimicRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER), false), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(MimicEntity e) {
        return Compat.rl("friend", "textures/entity/mimic/skin_" + e.getSkin() + ".png");
    }
}
