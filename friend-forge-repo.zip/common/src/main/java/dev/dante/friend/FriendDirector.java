package dev.dante.friend;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/** Server-side visit scheduler + chase logic (port of the Bedrock main.js rules). */
public class FriendDirector {
    private final Random rng = new Random();
    private FriendEntity friend;
    private UUID friendId;
    private long nextVisit = -1;
    private int age, unseen, chaseTicks, scareHold = -1, scareCooldown, cameoLeft;
    private int mode = -1;

    @SubscribeEvent
    public void commands(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSourceStack> d = e.getDispatcher();
        var root = Commands.literal("friend").requires(s -> s.hasPermission(2));
        for (String m : new String[]{"watch", "stalk", "chase"}) {
            int mm = m.equals("watch") ? 0 : m.equals("stalk") ? 1 : 2;
            root.then(Commands.literal(m).executes(c -> {
                ServerPlayer p = c.getSource().getPlayerOrException();
                vanishSilently();
                spawn(p, mm);
                return 1;
            }));
        }
        root.then(Commands.literal("vanish").executes(c -> { vanishSilently(); nextVisit = -1; return 1; }));
        d.register(root);
    }

    private void vanishSilently() {
        if (friend != null && friend.isAlive()) friend.discard();
        friend = null; mode = -1;
    }

    @SubscribeEvent
    public void tick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        var server = e.getServer();
        ServerLevel lvl = server.overworld();
        long now = lvl.getGameTime();
        List<ServerPlayer> players = new ArrayList<>();
        for (ServerPlayer p : lvl.players()) if (!p.isSpectator() && !p.isCreative() && p.isAlive()) players.add(p);

        if (friend != null && (!friend.isAlive() || friend.isRemoved())) { friend = null; mode = -1; }

        if (friend == null) {
            if (players.isEmpty()) return;
            if (nextVisit < 0) nextVisit = now + (60 + rng.nextInt(120)) * 20L;
            if (now >= nextVisit) {
                ServerPlayer p = players.get(rng.nextInt(players.size()));
                int day = (int) ((lvl.getDayTime() / 24000L) % 6);
                int m = day == 5 ? 2 : day == 1 ? 0 : day == 0 ? 0 : 1;
                spawn(p, m);
                if (day == 0 && friend != null) cameoLeft = 2;
            }
            return;
        }

        age++;
        ServerPlayer near = nearest(players);
        double nd = near == null ? 1e9 : near.distanceTo(friend);
        if (near != null) friend.setTargetPlayer(near.getUUID());

        if (cameoLeft > 0 && --cameoLeft == 0) { endVisit(false, now); return; }

        if (mode != FriendEntity.CHASE) {
            unseen = nd > 160 ? unseen + 1 : 0;
            if (unseen > 240 || (mode == FriendEntity.WATCH && nd > 85)) { endVisit(false, now); return; }
            for (ServerPlayer p : players) {
                if (seenBy(p)) {
                    p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 200, 0, false, false));
                    p.playNotifySound(SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 1f, 0.7f);
                    endVisit(true, now);
                    return;
                }
            }
            return;
        }

        // ---- chase
        chaseTicks++;
        if (scareCooldown > 0) scareCooldown--;
        if (nd > 70) unseen++; else unseen = 0;
        if (unseen > 200) { endVisit(false, now); return; }
        if (chaseTicks >= 1200) {
            for (ServerPlayer p : players) p.displayClientMessage(Component.literal("You survived."), false);
            endVisit(true, now);
            return;
        }
        for (ServerPlayer p : players) {
            double d = p.distanceTo(friend);
            if (d > 70) continue;
            if (chaseTicks % 40 == 1) p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 80, 0, false, false));
            int period = (int) Math.max(8, 20 - 12 * (chaseTicks / 1200.0));
            if (chaseTicks % period == 0) p.playNotifySound(SoundEvents.WARDEN_HEARTBEAT, SoundSource.HOSTILE, 1.2f, 1f);
            if (chaseTicks % 386 == 1) p.playNotifySound(FriendMod.THEME.get(), SoundSource.MUSIC, 1f, 1f);
            if (chaseTicks % 365 == 1) p.playNotifySound(FriendMod.SCREAM.get(), SoundSource.HOSTILE, 0.8f, 1f);
        }
        if (scareHold >= 0) {
            scareHold++;
            if (near != null) friend.getLookControl().setLookAt(near, 90f, 90f);
            if (scareHold >= 36) {
                friend.setAction(FriendEntity.ACT_NONE);
                friend.frozen = false;
                scareHold = -1; scareCooldown = 200;
                if (near != null) near.hurt(lvl.damageSources().generic(), Float.MAX_VALUE);
            }
        } else if (near != null && nd < 6 && scareCooldown == 0) {
            scareHold = 0;
            friend.frozen = true;
            friend.setAction(FriendEntity.ACT_JUMPSCARE);
            near.playNotifySound(FriendMod.ROAR.get(), SoundSource.HOSTILE, 1f, 1.2f);
        }
        if (chaseTicks == 30 && friend.getAction() == FriendEntity.ACT_ROAR) friend.setAction(FriendEntity.ACT_NONE);
    }

    private void spawn(ServerPlayer p, int m) {
        ServerLevel lvl = p.serverLevel();
        Vec3 pos = null;
        for (int i = 0; i < 24 && pos == null; i++) {
            double a = rng.nextDouble() * Math.PI * 2, r = 36 + rng.nextDouble() * 16;
            int x = (int) (p.getX() + Math.cos(a) * r), z = (int) (p.getZ() + Math.sin(a) * r);
            if (!lvl.hasChunkAt(new BlockPos(x, 64, z))) continue;
            int y = lvl.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            BlockPos bp = new BlockPos(x, y, z);
            if (!lvl.getBlockState(bp.below()).isSolid() || !lvl.getFluidState(bp).isEmpty()) continue;
            Vec3 c = new Vec3(x + 0.5, y, z + 0.5);
            if (m == 0 && i < 16 && isLookingAt(p, c)) continue;
            pos = c;
        }
        if (pos == null) { nextVisit = lvl.getGameTime() + 20 * 20; return; }
        FriendEntity f = FriendMod.FRIEND.get().create(lvl);
        if (f == null) return;
        f.moveTo(pos.x, pos.y, pos.z, 0, 0);
        f.setPhase(m);
        f.setTargetPlayer(p.getUUID());
        lvl.addFreshEntity(f);
        friend = f; friendId = f.getUUID(); mode = m;
        age = 0; unseen = 0; chaseTicks = 0; scareHold = -1; scareCooldown = 0; cameoLeft = 0;
        if (m == 2) {
            f.setAction(FriendEntity.ACT_ROAR);
            for (ServerPlayer q : lvl.players()) {
                if (q.distanceTo(f) > 70) continue;
                q.connection.send(new ClientboundSetTitlesAnimationPacket(5, 40, 10));
                q.connection.send(new ClientboundSetTitleTextPacket(Component.literal("RUN")));
                q.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 80, 0, false, false));
                q.playNotifySound(FriendMod.ROAR.get(), SoundSource.HOSTILE, 1f, 1f);
            }
        }
    }

    private void endVisit(boolean puff, long now) {
        if (friend != null) {
            if (puff && friend.level() instanceof ServerLevel sl)
                sl.sendParticles(ParticleTypes.POOF, friend.getX(), friend.getY() + 1.4, friend.getZ(), 25, 0.4, 0.8, 0.4, 0.02);
            friend.discard();
        }
        friend = null; mode = -1; cameoLeft = 0;
        nextVisit = now + (240 + rng.nextInt(360)) * 20L;
    }

    private ServerPlayer nearest(List<ServerPlayer> ps) {
        ServerPlayer b = null; double bd = 1e18;
        for (ServerPlayer p : ps) { double d = p.distanceToSqr(friend); if (d < bd) { bd = d; b = p; } }
        return b;
    }

    private boolean seenBy(ServerPlayer p) {
        if (p.distanceTo(friend) > 64) return false;
        return isLookingAt(p, friend.getEyePosition()) && p.hasLineOfSight(friend);
    }

    private static boolean isLookingAt(ServerPlayer p, Vec3 target) {
        Vec3 to = target.subtract(p.getEyePosition()).normalize();
        return p.getViewVector(1f).dot(to) > Math.cos(Math.toRadians(38));
    }
}
