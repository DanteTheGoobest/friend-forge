package dev.dante.friend;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/** Server-side visit scheduler + chase logic (port of the Bedrock main.js rules). */
public class FriendDirector {
    public static final FriendDirector INSTANCE = new FriendDirector();
    public static boolean hardcore = false;
    private final Random rng = new Random();
    private FriendEntity friend;
    private UUID friendId;
    private long nextVisit = -1;
    private int age, unseen, chaseTicks, scareHold = -1, scareCooldown, cameoLeft;
    private int mode = -1;
    private static final int WINDOW = 4;
    private BlockPos winPos; private int winEnd, winStare, winUnseen, winNextTap, winTapIdx; private boolean winFrozen;
    private UUID scareVictim;
    private double scareX, scareY, scareZ;

    @SubscribeEvent
    public void commands(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSourceStack> d = e.getDispatcher();
        var root = Commands.literal("friend").requires(s -> s.hasPermission(2));
        root.then(Commands.literal("window").executes(c -> {
            ServerPlayer p = c.getSource().getPlayerOrException();
            vanishSilently();
            if (!trySpawnWindow(p.serverLevel(), p)) c.getSource().sendFailure(Component.literal("[friend] no usable window within 7 blocks of you (glass with air on both sides, you on the inside)"));
            return 1;
        }));
        for (String m : new String[]{"watch", "stalk", "chase", "appear"}) {
            int mm = m.equals("watch") ? 0 : m.equals("stalk") ? 1 : m.equals("chase") ? 2 : 3;
            root.then(Commands.literal(m).executes(c -> {
                ServerPlayer p = c.getSource().getPlayerOrException();
                vanishSilently();
                spawn(p, mm);
                return 1;
            }));
        }
        root.then(Commands.literal("debug").executes(c -> {
            CommandSourceStack s = c.getSource();
            if (friend == null) { s.sendSuccess(() -> Component.literal("[friend] none active; nextVisit in " + (nextVisit < 0 ? -1 : (nextVisit - s.getServer().overworld().getGameTime()) / 20) + "s"), false); return 1; }
            ServerPlayer p = s.getPlayerOrException();
            String m = "[friend] mode=" + mode + " phase=" + friend.getPhase() + " action=" + friend.getAction()
                + " pos=" + (int) friend.getX() + "," + (int) friend.getY() + "," + (int) friend.getZ()
                + " dist=" + (int) p.distanceTo(friend) + " navDone=" + friend.getNavigation().isDone()
                + " speedAttr=" + friend.getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED)
                + " looking=" + isLookingAt(p, friend.getEyePosition()) + " los=" + p.hasLineOfSight(friend)
                + " chaseTicks=" + chaseTicks;
            s.sendSuccess(() -> Component.literal(m), false);
            return 1;
        }));
        root.then(Commands.literal("hardcore")
            .then(Commands.literal("on").executes(c -> { hardcore = true; c.getSource().sendSuccess(() -> Component.literal("[friend] hardcore ON (he smashes doors and windows)"), false); return 1; }))
            .then(Commands.literal("off").executes(c -> { hardcore = false; c.getSource().sendSuccess(() -> Component.literal("[friend] hardcore OFF"), false); return 1; })));
        root.then(Commands.literal("mimic")
            .executes(c -> { ServerPlayer p = c.getSource().getPlayerOrException(); Extras.forceMimic(p, false); return 1; })
            .then(Commands.literal("follow").executes(c -> { ServerPlayer p = c.getSource().getPlayerOrException(); Extras.forceMimic(p, true); return 1; })));
        root.then(Commands.literal("vanish").executes(c -> { vanishSilently(); nextVisit = -1; return 1; }));
        d.register(root);
    }

    private void vanishSilently() {
        if (friend != null && friend.isAlive()) friend.discard();
        friend = null; mode = -1;
    }

    @SubscribeEvent
    public void tick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        var server = e.getServer();
        ServerLevel lvl = server.overworld();
        long now = lvl.getGameTime();
        List<ServerPlayer> players = new ArrayList<>();
        for (ServerPlayer p : lvl.players()) if (!p.isSpectator() && p.isAlive()) players.add(p);

        if (friend != null && (!friend.isAlive() || friend.isRemoved())) { friend = null; mode = -1; }

        if (friend == null) {
            if (players.isEmpty()) return;
            if (nextVisit < 0) nextVisit = now + (60 + rng.nextInt(120)) * 20L;
            if (now >= nextVisit) {
                ServerPlayer p = players.get(rng.nextInt(players.size()));
                int day = (int) ((lvl.getDayTime() / 24000L) % 6);
                int m = day == 5 ? 2 : day == 1 ? 0 : day == 0 ? 3 : 1;
                boolean night = (lvl.getDayTime() % 24000L) >= 13000L;
                if (m != 2 && m != 3 && rng.nextDouble() < (night ? 0.5 : 0.15) && trySpawnWindow(lvl, p)) { /* window visit */ }
                else spawn(p, m);
            }
            return;
        }

        age++;
        ServerPlayer near = nearest(players);
        double nd = near == null ? 1e9 : near.distanceTo(friend);
        if (near != null) friend.setTargetPlayer(near.getUUID());

        if (mode == FriendEntity.APPEAR && age >= 60) { endVisit(true, now); return; }

        if (mode == WINDOW) { updateWindow(lvl, players, near, nd, now); return; }

        if (mode != FriendEntity.CHASE) {
            unseen = nd > 160 ? unseen + 1 : 0;
            if (unseen > 240 || (mode == FriendEntity.WATCH && nd > 85)) { endVisit(false, now); return; }
            for (ServerPlayer p : players) {
                if (seenBy(p)) {
                    p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 200, 0, false, false));
                    p.playNotifySound(SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 1f, 0.7f);
                    endVisit(true, now);
                    return;
                }
            }
            return;
        }

        // ---- chase
        chaseTicks++;
        if (scareCooldown > 0) scareCooldown--;
        if (nd > 70) unseen++; else unseen = 0;
        if (unseen > 200) { endVisit(false, now); return; }
        if (chaseTicks >= 1200) {
            for (ServerPlayer p : players) p.displayClientMessage(Component.literal("You survived."), false);
            endVisit(true, now);
            return;
        }
        for (ServerPlayer p : players) {
            double d = p.distanceTo(friend);
            if (d > 70) continue;
            if (chaseTicks % 10 == 1) {
                p.connection.send(new ClientboundSetTitlesAnimationPacket(0, 40, 5));
                p.connection.send(new ClientboundSetTitleTextPacket(Component.literal("RUN").withStyle(net.minecraft.ChatFormatting.DARK_RED, net.minecraft.ChatFormatting.BOLD)));
            }
            if (chaseTicks % 40 == 1) p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 80, 0, false, false));
            int period = (int) Math.max(8, 20 - 12 * (chaseTicks / 1200.0));
            if (chaseTicks % period == 0) p.playNotifySound(SoundEvents.WARDEN_HEARTBEAT, SoundSource.HOSTILE, 1.2f, 1f);
            if (chaseTicks % 386 == 1) p.playNotifySound(FriendMod.THEME.get(), SoundSource.MASTER, 1f, 1f);
            if (chaseTicks % 365 == 1) p.playNotifySound(FriendMod.SCREAM.get(), SoundSource.MASTER, 0.8f, 1f);
        }
        if (chaseTicks % 5 == 0) {
            var sp = friend.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED);
            if (sp != null) sp.setBaseValue(nd > 25 ? 0.45 : 0.31);
        }
        if (scareHold >= 0) {
            scareHold++;
            ServerPlayer victim = scareVictim == null ? null : lvl.getServer().getPlayerList().getPlayer(scareVictim);
            if (victim == null || !victim.isAlive()) { scareHold = -1; friend.frozen = false; friend.setAction(FriendEntity.ACT_NONE); }
            else {
                // pin the victim and make them face Friend's head
                Vec3 fe = friend.getEyePosition();
                double dx = fe.x - victim.getX(), dy = fe.y - victim.getEyeY(), dz = fe.z - victim.getZ();
                float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
                float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
                victim.connection.teleport(scareX, scareY, scareZ, yaw, pitch);
                if (scareHold >= 36) {
                    friend.setAction(FriendEntity.ACT_NONE);
                    friend.frozen = false;
                    scareHold = -1; scareCooldown = 200;
                    victim.hurt(lvl.damageSources().generic(), Float.MAX_VALUE);
                }
            }
        } else if (near != null && nd < 6 && scareCooldown == 0) {
            scareHold = 0;
            scareVictim = near.getUUID();
            friend.frozen = true;
            // appear right in front of the victim
            Vec3 look = near.getViewVector(1f); Vec3 flat = new Vec3(look.x, 0, look.z).normalize();
            double fx = near.getX() + flat.x * 1.4, fz = near.getZ() + flat.z * 1.4;
            friend.moveTo(fx, near.getY(), fz, near.getYRot() + 180f, 0f);
            friend.getNavigation().stop();
            scareX = near.getX(); scareY = near.getY(); scareZ = near.getZ();
            friend.setAction(FriendEntity.ACT_JUMPSCARE);
            near.playNotifySound(FriendMod.ROAR.get(), SoundSource.HOSTILE, 1f, 1.2f);
            near.playNotifySound(FriendMod.SCREAM.get(), SoundSource.HOSTILE, 1f, 1.1f);
        }
        if (chaseTicks == 30 && friend.getAction() == FriendEntity.ACT_ROAR) friend.setAction(FriendEntity.ACT_NONE);
    }

    private void spawn(ServerPlayer p, int m) { spawnAt(p, m, null); }

    private void spawnAt(ServerPlayer p, int m, Vec3 forced) {
        ServerLevel lvl = p.serverLevel();
        Vec3 pos = forced;
        for (int i = 0; i < 24 && pos == null; i++) {
            double a = rng.nextDouble() * Math.PI * 2, r = (m == 2 ? 26 + rng.nextDouble() * 14 : 36 + rng.nextDouble() * 16);
            int x = (int) (p.getX() + Math.cos(a) * r), z = (int) (p.getZ() + Math.sin(a) * r);
            if (!lvl.hasChunkAt(new BlockPos(x, 64, z))) continue;
            int y = lvl.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            BlockPos bp = new BlockPos(x, y, z);
            if (!lvl.getBlockState(bp.below()).isSolid() || !lvl.getFluidState(bp).isEmpty()) continue;
            Vec3 c = new Vec3(x + 0.5, y, z + 0.5);
            if ((m == 0 || m == 3) && i < 16 && isLookingAt(p, c)) continue;
            pos = c;
        }
        if (pos == null) { nextVisit = lvl.getGameTime() + 20 * 20; return; }
        FriendEntity f = FriendMod.FRIEND.get().create(lvl);
        if (f == null) return;
        f.moveTo(pos.x, pos.y, pos.z, 0, 0);
        f.setPhase(m);
        f.setTargetPlayer(p.getUUID());
        lvl.addFreshEntity(f);
        friend = f; friendId = f.getUUID(); mode = m;
        age = 0; unseen = 0; chaseTicks = 0; scareHold = -1; scareCooldown = 0; cameoLeft = 0;
        if (m == 2) announceChase(lvl, f);
    }

    private void announceChase(ServerLevel lvl, FriendEntity f) {
        f.setAction(FriendEntity.ACT_ROAR);
        for (ServerPlayer q : lvl.players()) {
            if (q.distanceTo(f) > 70) continue;
            q.connection.send(new ClientboundSetTitlesAnimationPacket(5, 40, 10));
            q.connection.send(new ClientboundSetTitleTextPacket(Component.literal("RUN").withStyle(net.minecraft.ChatFormatting.DARK_RED, net.minecraft.ChatFormatting.BOLD)));
            q.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 80, 0, false, false));
            q.playNotifySound(FriendMod.ROAR.get(), SoundSource.MASTER, 1f, 1f);
        }
    }


    // ------------------------------------------------------------------ window visits
    private static boolean isWindow(net.minecraft.world.level.block.state.BlockState s) {
        if (s.is(net.minecraft.world.level.block.Blocks.IRON_BARS)) return false;
        return Compat.isGlassBlock(s)
                || s.getBlock() instanceof net.minecraft.world.level.block.IronBarsBlock;
    }
    private static boolean air(ServerLevel l, BlockPos p) { return l.getBlockState(p).isAir(); }

    private boolean trySpawnWindow(ServerLevel lvl, ServerPlayer p) {
        int R = 7, px = p.getBlockX(), py = p.getBlockY(), pz = p.getBlockZ();
        List<double[]> found = new ArrayList<>();
        int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        for (int x = px - R; x <= px + R; x++) for (int z = pz - R; z <= pz + R; z++) for (int y = py - 1; y <= py + 3; y++) {
            BlockPos wp = new BlockPos(x, y, z);
            if (!isWindow(lvl.getBlockState(wp))) continue;
            for (int[] dd : dirs) {
                int dx = dd[0], dz = dd[1];
                if (!air(lvl, wp.offset(dx, 0, dz)) || !air(lvl, wp.offset(-dx, 0, -dz))) continue;
                double qx = p.getX() - (x + 0.5), qz = p.getZ() - (z + 0.5);
                if (qx * -dx + qz * -dz < 0.5) continue;
                if (Math.hypot(qx, qz) > R) continue;
                for (int y0 : new int[]{y - 1, y - 2}) {
                    BlockPos ground = new BlockPos(x + dx, y0 - 1, z + dz);
                    if (!lvl.getBlockState(ground).isSolid()) continue;
                    boolean room = true;
                    for (int k = 0; k < 3; k++) if (!air(lvl, new BlockPos(x + dx, y0 + k, z + dz))) room = false;
                    if (!room || !air(lvl, new BlockPos(x + 2 * dx, y0 + 1, z + 2 * dz))) continue;
                    found.add(new double[]{x, y, z, x + dx + 0.5 - dx * 0.12, y0, z + dz + 0.5 - dz * 0.12});
                    break;
                }
            }
        }
        if (found.isEmpty()) return false;
        double[] w = found.get(rng.nextInt(found.size()));
        FriendEntity f = FriendMod.FRIEND.get().create(lvl);
        if (f == null) return false;
        f.moveTo(w[3], w[4], w[5], 0, 0);
        f.setPhase(FriendEntity.WATCH);
        f.setTargetPlayer(p.getUUID());
        f.setAction(FriendEntity.ACT_TAP);
        lvl.addFreshEntity(f);
        friend = f; friendId = f.getUUID(); mode = WINDOW;
        winPos = new BlockPos((int) w[0], (int) w[1], (int) w[2]);
        winEnd = 20 * (14 + rng.nextInt(11));
        winStare = 0; winUnseen = 0; winNextTap = 16; winTapIdx = 0; winFrozen = false;
        age = 0; unseen = 0; chaseTicks = 0; scareHold = -1; scareCooldown = 0;
        return true;
    }

    private void updateWindow(ServerLevel lvl, List<ServerPlayer> players, ServerPlayer near, double nd, long now) {
        if (near == null || nd > 22) { endVisit(false, now); return; }
        double dx = near.getX() - friend.getX(), dz = near.getZ() - friend.getZ();
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        friend.setYRot(yaw); friend.setYHeadRot(yaw); friend.yBodyRot = yaw;
        if (age >= winEnd) { endVisit(true, now); return; }
        boolean seen = false;
        for (ServerPlayer p : players) if (p.distanceTo(friend) <= 30 && isLookingAt(p, friend.getEyePosition()) && p.hasLineOfSight(friend)) { seen = true; break; }
        if (seen) {
            winStare++; winUnseen = 0;
            if (!winFrozen) { winFrozen = true; friend.setAction(FriendEntity.ACT_NONE); }
            if (winStare >= 70) {
                for (ServerPlayer p : players) if (p.distanceTo(friend) <= 30) p.playNotifySound(SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 0.8f, 0.5f);
                endVisit(true, now);
            }
            return;
        }
        winUnseen++;
        if (winFrozen) {
            if (winUnseen < 40) return;
            winFrozen = false; winNextTap = age + 10; friend.setAction(FriendEntity.ACT_TAP);
        }
        // Hardcore: after a while of tapping he smashes the window and the chase begins
        if (hardcore && age > 160) {
            lvl.destroyBlock(winPos, false);
            friend.playSound(FriendMod.DOOR.get(), 1f, 1f);
            mode = FriendEntity.CHASE; chaseTicks = 0; unseen = 0;
            friend.setPhase(FriendEntity.CHASE);
            announceChase(lvl, friend);
            return;
        }
        if (age >= winNextTap) {
            lvl.playSound(null, winPos, SoundEvents.GLASS_HIT, SoundSource.BLOCKS, 1.0f, 0.85f + rng.nextFloat() * 0.2f);
            winTapIdx++;
            winNextTap = age + (winTapIdx % 3 == 0 ? 28 : 6);
        }
    }

    /** Called when a Mimic drops the act: a real chase starts right where it stood. */
    public void startChaseAt(ServerLevel lvl, double x, double y, double z, ServerPlayer target) {
        ServerPlayer p = target;
        if (p == null || !p.isAlive()) { for (ServerPlayer q : lvl.players()) { p = q; break; } }
        if (p == null) return;
        vanishSilently();
        spawnAt(p, 2, new Vec3(x, y, z));
    }

    /** True while a real Friend is out. */
    public boolean friendActive() { return friend != null; }

    private void endVisit(boolean puff, long now) {
        if (friend != null) {
            if (puff && friend.level() instanceof ServerLevel sl)
                sl.sendParticles(ParticleTypes.POOF, friend.getX(), friend.getY() + 1.4, friend.getZ(), 25, 0.4, 0.8, 0.4, 0.02);
            friend.discard();
        }
        friend = null; mode = -1; cameoLeft = 0;
        nextVisit = now + (240 + rng.nextInt(360)) * 20L;
    }

    private ServerPlayer nearest(List<ServerPlayer> ps) {
        ServerPlayer b = null; double bd = 1e18;
        for (ServerPlayer p : ps) { double d = p.distanceToSqr(friend); if (d < bd) { bd = d; b = p; } }
        return b;
    }

    private boolean seenBy(ServerPlayer p) {
        if (p.distanceTo(friend) > 64) return false;
        return isLookingAt(p, friend.getEyePosition()) && p.hasLineOfSight(friend);
    }

    private static boolean isLookingAt(ServerPlayer p, Vec3 target) {
        Vec3 to = target.subtract(p.getEyePosition()).normalize();
        return p.getViewVector(1f).dot(to) > Math.cos(Math.toRadians(38));
    }
}
