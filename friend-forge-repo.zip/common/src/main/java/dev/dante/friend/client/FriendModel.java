package dev.dante.friend.client;

import dev.dante.friend.Compat;
import dev.dante.friend.FriendEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class FriendModel extends GeoModel<FriendEntity> {
    @Override public ResourceLocation getModelResource(FriendEntity e) { return Compat.rl("friend", "geo/entity/friend.geo.json"); }
    @Override public ResourceLocation getTextureResource(FriendEntity e) { return Compat.rl("friend", "textures/entity/friend.png"); }
    @Override public ResourceLocation getAnimationResource(FriendEntity e) { return Compat.rl("friend", "animations/entity/friend.animation.json"); }
}
