package dev.dante.friend;

import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

public final class ModEvents {
    private ModEvents() {}
    public static void onAttributes(EntityAttributeCreationEvent e) {
        e.put(FriendMod.FRIEND.get(), FriendEntity.attributes().build());
        e.put(FriendMod.MIMIC.get(), MimicEntity.attributes().build());
        e.put(FriendMod.FOLLOWER.get(), MimicEntity.attributes().build());
    }
}
