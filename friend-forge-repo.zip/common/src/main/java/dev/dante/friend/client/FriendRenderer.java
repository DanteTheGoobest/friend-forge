package dev.dante.friend.client;

import dev.dante.friend.FriendEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class FriendRenderer extends GeoEntityRenderer<FriendEntity> {
    public FriendRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new FriendModel());
        this.shadowRadius = 0.5f;
    }
}
