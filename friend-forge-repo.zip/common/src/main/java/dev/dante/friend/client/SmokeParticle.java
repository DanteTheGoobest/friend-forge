package dev.dante.friend.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

/** Friend's black smoke puff (the custom smoke texture from the Bedrock add-on). */
public class SmokeParticle extends TextureSheetParticle {
    private final SpriteSet sprites;

    protected SmokeParticle(ClientLevel l, double x, double y, double z, double xd, double yd, double zd, SpriteSet sprites) {
        super(l, x, y, z, xd, yd, zd);
        this.sprites = sprites;
        this.lifetime = 32 + this.random.nextInt(24);
        this.quadSize = 0.55f + this.random.nextFloat() * 0.4f;
        this.xd = xd + (this.random.nextDouble() - 0.5) * 0.12;
        this.yd = yd + 0.02 + this.random.nextDouble() * 0.06;
        this.zd = zd + (this.random.nextDouble() - 0.5) * 0.12;
        this.friction = 0.9f;
        this.gravity = -0.01f;
        this.rCol = 0.04f; this.gCol = 0.04f; this.bCol = 0.04f;
        this.pickSprite(sprites);
    }

    @Override
    public void tick() {
        super.tick();
        float t = (float) this.age / (float) this.lifetime;
        this.alpha = t < 0.6f ? 0.9f : Math.max(0f, 0.9f * (1f - (t - 0.6f) / 0.4f));
    }

    @Override public ParticleRenderType getRenderType() { return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT; }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        public Provider(SpriteSet s) { this.sprites = s; }
        @Override
        public Particle createParticle(SimpleParticleType t, ClientLevel l, double x, double y, double z, double xd, double yd, double zd) {
            return new SmokeParticle(l, x, y, z, xd, yd, zd, sprites);
        }
    }
}
