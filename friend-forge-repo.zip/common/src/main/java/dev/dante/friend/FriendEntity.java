package dev.dante.friend;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import java.util.UUID;

public class FriendEntity extends FriendBase {
    public static final int WATCH = 0, STALK = 1, CHASE = 2, APPEAR = 3;
    public static final int ACT_NONE = 0, ACT_TAP = 1, ACT_JUMPSCARE = 2, ACT_ROAR = 3;

    private UUID target;
    public boolean frozen;
    private net.minecraft.world.phys.Vec3 lastPos;
    private int stuck;

    public FriendEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        setPersistenceRequired();
        setInvulnerable(true);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder attributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 100)
                .add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.FOLLOW_RANGE, 160)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    
    public void setPhase(int p) {
        rawPhase(p);
        var a = getAttribute(Attributes.MOVEMENT_SPEED);
        if (a != null) a.setBaseValue(p == CHASE ? 0.31 : p == STALK ? 0.16 : 0.23);
    }
    public void setTargetPlayer(UUID id) { this.target = id; }

    @Override
    protected net.minecraft.world.entity.ai.navigation.PathNavigation createNavigation(Level l) {
        GroundPathNavigation n = new GroundPathNavigation(this, l);
        return n;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (frozen) { getNavigation().stop(); return; }
        Player t = target == null ? null : level().getPlayerByUUID(target);
        if (t == null) return;
        getLookControl().setLookAt(t, 60f, 60f);
        if (getPhase() == WATCH || getPhase() == APPEAR) { getNavigation().stop(); return; }
        smashAhead(t);
        updateCrawl(t);
        double d2 = distanceToSqr(t);
        if (d2 > 9.0) {
            if (tickCount % 10 == 0 || getNavigation().isDone()) getNavigation().moveTo(t, 1.0);
            // fallback: if pathing is not getting us anywhere, walk straight at the target
            if (tickCount % 10 == 0) {
                if (lastPos != null && lastPos.distanceToSqr(position()) < 0.09) stuck++; else stuck = 0;
                lastPos = position();
            }
            if (stuck >= 2 || isCrawling()) {
                double sp = getAttributeValue(Attributes.MOVEMENT_SPEED) * 0.9;
                net.minecraft.world.phys.Vec3 dir = new net.minecraft.world.phys.Vec3(t.getX() - getX(), 0, t.getZ() - getZ()).normalize();
                setDeltaMovement(dir.x * sp, getDeltaMovement().y + (horizontalCollision && onGround() ? 0.45 : 0), dir.z * sp);
                setYRot((float) (Math.toDegrees(Math.atan2(dir.z, dir.x)) - 90.0));
            }
        } else getNavigation().stop();
    }

    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public boolean isPushable() { return false; }
    @Override public boolean isInvulnerableTo(net.minecraft.world.damagesource.DamageSource s) {
        return !s.is(net.minecraft.tags.DamageTypeTags.BYPASSES_INVULNERABILITY);
    }

    @Override public void addAdditionalSaveData(CompoundTag t) { super.addAdditionalSaveData(t); }
    @Override public void readAdditionalSaveData(CompoundTag t) { super.readAdditionalSaveData(t); }

    /** Hardcore mode: in a chase he smashes doors and windows that block his way. */
    private void smashAhead(Player t) {
        if (!FriendDirector.hardcore || getPhase() != CHASE || getTags().contains("friend_fake") || tickCount % 8 != 0) return;
        double dx = t.getX() - getX(), dz = t.getZ() - getZ();
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 1.5) return;
        dx /= len; dz /= len;
        for (int i = 1; i <= 2; i++) {
            net.minecraft.core.BlockPos base = blockPosition().offset((int) Math.round(dx * i), 0, (int) Math.round(dz * i));
            for (int h = 0; h < 3; h++) {
                net.minecraft.core.BlockPos bp = base.above(h);
                net.minecraft.world.level.block.state.BlockState s = level().getBlockState(bp);
                if (breakable(s)) {
                    level().destroyBlock(bp, false);
                    playSound(FriendMod.DOOR.get(), 1f, 1f);
                    return;
                }
            }
        }
    }

    private static boolean breakable(net.minecraft.world.level.block.state.BlockState s) {
        if (s.is(net.minecraft.tags.BlockTags.WOODEN_DOORS) || s.is(net.minecraft.tags.BlockTags.WOODEN_TRAPDOORS) || s.is(net.minecraft.tags.BlockTags.FENCE_GATES)) return true;
        if (s.is(net.minecraft.world.level.block.Blocks.IRON_BARS)) return false;
        return Compat.isGlassBlock(s)
                || s.getBlock() instanceof net.minecraft.world.level.block.IronBarsBlock;
    }

    // ---- crawling: drop to a 0.9-high hitbox to follow you through 1-2 block gaps
    private int clearTicks;
    private int freeAbove(net.minecraft.core.BlockPos p) {
        int n = 0;
        for (int k = 0; k < 3; k++) {
            net.minecraft.world.level.block.state.BlockState s = level().getBlockState(p.above(k));
            if (!s.getCollisionShape(level(), p.above(k)).isEmpty()) break;
            n++;
        }
        return n;
    }
    private void updateCrawl(Player t) {
        if (getPhase() == WATCH || getPhase() == APPEAR || getTags().contains("friend_fake")) return;
        double dx = t.getX() - getX(), dz = t.getZ() - getZ();
        double len = Math.sqrt(dx * dx + dz * dz);
        boolean low = false;
        if (len > 0.5) {
            for (double d : new double[]{0.9, 1.6}) {
                net.minecraft.core.BlockPos bp = net.minecraft.core.BlockPos.containing(getX() + dx / len * d, getY() + 0.01, getZ() + dz / len * d);
                int free = freeAbove(bp);
                if (free >= 1 && free < 3) { low = true; break; }
            }
        }
        if (!isCrawling()) { if (low) { setCrawling(true); clearTicks = 0; } return; }
        net.minecraft.core.BlockPos here = blockPosition();
        if (low || freeAbove(here) < 3) clearTicks = 0;
        else if (++clearTicks >= 10) setCrawling(false);
    }
}
