package dev.dante.friend;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.UUID;

public class FriendEntity extends FriendBase implements GeoEntity {
    public static final int WATCH = 0, STALK = 1, CHASE = 2;
    public static final int ACT_NONE = 0, ACT_JUMPSCARE = 2, ACT_ROAR = 3;

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private UUID target;
    public boolean frozen;

    public FriendEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        setPersistenceRequired();
        setInvulnerable(true);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder attributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 100)
                .add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.FOLLOW_RANGE, 160)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    
    public void setPhase(int p) {
        rawPhase(p);
        var a = getAttribute(Attributes.MOVEMENT_SPEED);
        if (a != null) a.setBaseValue(p == CHASE ? 0.31 : p == STALK ? 0.16 : 0.23);
    }
    public void setTargetPlayer(UUID id) { this.target = id; }

    @Override
    protected net.minecraft.world.entity.ai.navigation.PathNavigation createNavigation(Level l) {
        GroundPathNavigation n = new GroundPathNavigation(this, l);
        return n;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (frozen) { getNavigation().stop(); return; }
        Player t = target == null ? null : level().getPlayerByUUID(target);
        if (t == null) return;
        getLookControl().setLookAt(t, 60f, 60f);
        if (getPhase() == WATCH) { getNavigation().stop(); return; }
        if (distanceToSqr(t) > 9.0) getNavigation().moveTo(t, 1.0);
        else getNavigation().stop();
    }

    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public boolean isPushable() { return false; }
    @Override public boolean isInvulnerableTo(net.minecraft.world.damagesource.DamageSource s) {
        return !s.is(net.minecraft.tags.DamageTypeTags.BYPASSES_INVULNERABILITY);
    }

    @Override public void addAdditionalSaveData(CompoundTag t) { super.addAdditionalSaveData(t); }
    @Override public void readAdditionalSaveData(CompoundTag t) { super.readAdditionalSaveData(t); }

    // ---- GeckoLib
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar c) {
        c.add(new AnimationController<>(this, "main", 5, this::predicate));
    }

    private <E extends GeoEntity> PlayState predicate(AnimationState<E> s) {
        int phase = getPhase(), act = getAction();
        String a;
        boolean once = false;
        if (act == ACT_JUMPSCARE) { a = "jumpscare"; once = true; }
        else if (act == ACT_ROAR) { a = "roar_scream"; once = true; }
        else if (s.isMoving()) a = phase == CHASE ? "run" : phase == STALK ? "stalk_jerk" : "walk";
        else a = phase == WATCH ? "watch_idle" : "idle_creep";
        RawAnimation r = once ? RawAnimation.begin().thenPlayAndHold("animation.friend." + a)
                              : RawAnimation.begin().thenLoop("animation.friend." + a);
        return s.setAndContinue(r);
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
