package dev.dante.friend.client;

import dev.dante.friend.FriendMod;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.IEventBus;

public final class ClientSetup {
    private ClientSetup() {}
    public static void init(IEventBus bus) {
        bus.addListener((EntityRenderersEvent.RegisterRenderers e) ->
                e.registerEntityRenderer(FriendMod.FRIEND.get(), FriendRenderer::new));
        HudHook.register();
    }
}
