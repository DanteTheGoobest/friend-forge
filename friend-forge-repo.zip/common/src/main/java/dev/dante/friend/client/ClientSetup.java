package dev.dante.friend.client;

import dev.dante.friend.FriendMod;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;

public final class ClientSetup {
    private ClientSetup() {}
    public static void init(IEventBus bus) {
        bus.addListener((EntityRenderersEvent.RegisterRenderers e) ->
                e.registerEntityRenderer(FriendMod.FRIEND.get(), FriendRenderer::new));
        MinecraftForge.EVENT_BUS.addListener((RenderGuiEvent.Post e) ->
                FriendHud.render(e.getGuiGraphics(), e.getWindow().getGuiScaledWidth(), e.getWindow().getGuiScaledHeight()));
    }
}
