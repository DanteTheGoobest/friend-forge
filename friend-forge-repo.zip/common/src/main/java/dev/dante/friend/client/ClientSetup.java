package dev.dante.friend.client;

import dev.dante.friend.FriendMod;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.eventbus.api.IEventBus;

public final class ClientSetup {
    private ClientSetup() {}
    public static void init(IEventBus bus) {
        bus.addListener((EntityRenderersEvent.RegisterRenderers e) ->
                e.registerEntityRenderer(FriendMod.FRIEND.get(), FriendRenderer::new));
        bus.addListener((RegisterGuiOverlaysEvent e) ->
                e.registerAboveAll("friend_phase", (gui, g, pt, w, h) -> FriendHud.render(g, w, h)));
    }
}
