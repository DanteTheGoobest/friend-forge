package dev.dante.friend;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(FriendMod.MODID)
public class FriendMod {
    public static final String MODID = "friend";

    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, MODID);

    public static final RegistryObject<EntityType<FriendEntity>> FRIEND = ENTITIES.register("friend",
            () -> EntityType.Builder.of(FriendEntity::new, MobCategory.MONSTER)
                    .sized(0.8f, 2.8f).clientTrackingRange(10).fireImmune()
                    .build(MODID + ":friend"));

    public static final RegistryObject<Item> FRIEND_EGG = ITEMS.register("friend_spawn_egg",
            () -> new ForgeSpawnEggItem(FRIEND, 0x111111, 0x8a0000, new Item.Properties()));

    public static final RegistryObject<SoundEvent> ROAR = sound("roar");
    public static final RegistryObject<SoundEvent> DOOR = sound("broke_down_door");
    public static final RegistryObject<SoundEvent> THEME = sound("chase_theme");
    public static final RegistryObject<SoundEvent> SCREAM = sound("scream");

    private static RegistryObject<SoundEvent> sound(String n) {
        return SOUNDS.register(n, () -> SoundEvent.createVariableRangeEvent(Compat.rl(MODID, n)));
    }

    public FriendMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(bus);
        ITEMS.register(bus);
        SOUNDS.register(bus);
        bus.addListener(ModEvents::onAttributes);
        bus.addListener((BuildCreativeModeTabContentsEvent e) -> {
            if (e.getTabKey() == CreativeModeTabs.SPAWN_EGGS) e.accept(FRIEND_EGG.get());
        });
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(new FriendDirector());
        net.minecraftforge.fml.DistExecutor.unsafeRunWhenOn(net.minecraftforge.api.distmarker.Dist.CLIENT,
                () -> () -> dev.dante.friend.client.ClientSetup.init(bus));
    }
}
