package dev.dante.friend;

import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(FriendMod.MODID)
public class FriendMod {
    public static final String MODID = "friend";

    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<ParticleType<?>> PARTICLES = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, MODID);
    public static final RegistryObject<SimpleParticleType> SMOKE = PARTICLES.register("smoke_puff", () -> new SimpleParticleType(false));
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, MODID);

    public static final RegistryObject<EntityType<FriendEntity>> FRIEND = ENTITIES.register("friend",
            () -> EntityType.Builder.of(FriendEntity::new, MobCategory.MONSTER)
                    .sized(0.8f, 2.8f).clientTrackingRange(10).fireImmune()
                    .build(MODID + ":friend"));

    public static final RegistryObject<EntityType<MimicEntity>> MIMIC = ENTITIES.register("mimic",
            () -> EntityType.Builder.<MimicEntity>of((t, l) -> new MimicEntity(t, l, false), MobCategory.MONSTER)
                    .sized(0.6f, 1.8f).clientTrackingRange(8).build(MODID + ":mimic"));
    public static final RegistryObject<EntityType<MimicEntity>> FOLLOWER = ENTITIES.register("follower",
            () -> EntityType.Builder.<MimicEntity>of((t, l) -> new MimicEntity(t, l, true), MobCategory.MONSTER)
                    .sized(0.6f, 1.8f).clientTrackingRange(8).build(MODID + ":follower"));

    public static final RegistryObject<Item> MIMIC_EGG = ITEMS.register("mimic_spawn_egg",
            () -> new ForgeSpawnEggItem(MIMIC, 0xFFFFFF, 0xFFFFFF, new Item.Properties()));
    public static final RegistryObject<Item> FOLLOWER_EGG = ITEMS.register("follower_spawn_egg",
            () -> new ForgeSpawnEggItem(FOLLOWER, 0xFFFFFF, 0xFFFFFF, new Item.Properties()));

    public static final RegistryObject<Item> FRIEND_EGG = ITEMS.register("friend_spawn_egg",
            () -> new ForgeSpawnEggItem(FRIEND, 0xFFFFFF, 0xFFFFFF, new Item.Properties()));

    public static final RegistryObject<SoundEvent> ROAR = sound("roar");
    public static final RegistryObject<SoundEvent> DOOR = sound("broke_down_door");
    public static final RegistryObject<SoundEvent> THEME = sound("chase_theme");
    public static final RegistryObject<SoundEvent> SCREAM = sound("scream");

    private static RegistryObject<SoundEvent> sound(String n) {
        return SOUNDS.register(n, () -> SoundEvent.createVariableRangeEvent(Compat.rl(MODID, n)));
    }

    public FriendMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(bus);
        ITEMS.register(bus);
        SOUNDS.register(bus);
        PARTICLES.register(bus);
        bus.addListener(ModEvents::onAttributes);
        bus.addListener((BuildCreativeModeTabContentsEvent e) -> {
            if (e.getTabKey() == CreativeModeTabs.SPAWN_EGGS) { e.accept(FRIEND_EGG.get()); e.accept(MIMIC_EGG.get()); e.accept(FOLLOWER_EGG.get()); }
        });
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(FriendDirector.INSTANCE);
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(new Extras());
        net.minecraftforge.fml.DistExecutor.unsafeRunWhenOn(net.minecraftforge.api.distmarker.Dist.CLIENT,
                () -> () -> dev.dante.friend.client.ClientSetup.init(bus));
    }
}
