package dev.dante.friend;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import java.util.EnumSet;
import java.util.Random;

/** A player look-alike. Wanderer walks around; follower walks after you. Getting close drops the act. */
public class MimicEntity extends MimicBase {
    public static final String[] LINES = {"you know too much.", "you know too much.", "you know too much.", "found you", "i see you", "behind you", "dont run", "look at me", "stay"};
    public static final String[] SAYINGS = {"anyone here?", "lol", "brb", "where are you", "hello?", "did you hear that", "hey", "wait", "nice base", "i'm lost", "can you come here", "why are you running", "lag", "what", "?", "hi", "look behind you", "same", "ok", "come here"};
    public static final int REVEAL_SKIN = 7;

    private final Random rnd = new Random();
    private final boolean follower;
    private String mimicName = "Steve";
    private String[] customLines;
    private boolean rare;
    private int revealTicks = -1;
    private int life, nextChat, nextJump;
    private ServerPlayer revealTarget;
    private final java.util.ArrayDeque<Integer> hist = new java.util.ArrayDeque<>();
    private int jumpCd, nextTwitch = 20 * 5;

    public MimicEntity(EntityType<? extends PathfinderMob> type, Level level, boolean follower) {
        super(type, level);
        this.follower = follower;
        setPersistenceRequired();
        nextChat = 20 * (25 + rnd.nextInt(50));
        nextJump = 20 * (10 + rnd.nextInt(30));
    }

    public static AttributeSupplier.Builder attributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20)
                .add(Attributes.MOVEMENT_SPEED, 0.23)
                .add(Attributes.FOLLOW_RANGE, 64);
    }

    public boolean isFollower() { return follower; }
    public boolean isRare() { return rare; }
    public String mimicName() { return mimicName; }

    public void setIdentity(String name, int skin, boolean rare, String[] lines) {
        this.mimicName = name; this.rare = rare; this.customLines = lines;
        setSkin(skin);
        setCustomName(Component.literal(name));
        setCustomNameVisible(true);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        if (follower) this.goalSelector.addGoal(2, new FollowGoal());
        else {
            this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 1.0));
            this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 10f));
            this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));
        }
    }

    private class FollowGoal extends Goal {
        FollowGoal() { setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK)); }
        @Override public boolean canUse() { return level().getNearestPlayer(MimicEntity.this, 80) != null; }
        @Override public void tick() {
            Player p = level().getNearestPlayer(MimicEntity.this, 80);
            if (p == null) return;
            double d = distanceTo(p);
            getLookControl().setLookAt(p, 30f, 30f);
            if (d > 4) { getNavigation().moveTo(p, d > 16 ? 1.5 : 1.0); setSprinting(d > 16); }
            else { getNavigation().stop(); setSprinting(false); }
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || !(level() instanceof ServerLevel sl)) return;
        life++;

        if (revealTicks >= 0) { tickReveal(sl); return; }

        Player near = sl.getNearestPlayer(this, 64);

        // reveal only when somebody walks up to it
        if (near instanceof ServerPlayer sp && !sp.isSpectator() && distanceTo(sp) < (follower ? 4 : 6)) { startReveal(sp); return; }

        // copies the nearest player a moment late: sneaking, jumping, swinging
        if (near != null && distanceTo(near) < 40) {
            int fl = (near.isShiftKeyDown() ? 1 : 0) | ((near.getDeltaMovement().y > 0.3 && !near.onGround()) ? 2 : 0) | ((near.swinging && near.swingTime == 0) ? 4 : 0);
            hist.addLast(fl);
            if (hist.size() > 27) hist.removeFirst();
            if (hist.size() >= 27) {
                int old = hist.peekFirst();
                setShiftKeyDown((old & 1) != 0);
                if (jumpCd > 0) jumpCd--;
                if ((old & 2) != 0 && onGround() && jumpCd <= 0) { jumpFromGround(); jumpCd = 10; }
                if ((old & 4) != 0) swing(net.minecraft.world.InteractionHand.MAIN_HAND);
            }
        }
        // twitches: a short, wrong head snap
        if (--nextTwitch <= 0) {
            nextTwitch = 20 * (3 + rnd.nextInt(7));
            setYHeadRot(getYHeadRot() + (rnd.nextBoolean() ? 1 : -1) * (40 + rnd.nextInt(40)));
        }

        // idle jump like a bored player
        if (--nextJump <= 0) { nextJump = 20 * (10 + rnd.nextInt(30)); if (onGround()) jumpFromGround(); }

        // chat
        if (--nextChat <= 0) {
            nextChat = 20 * (25 + rnd.nextInt(50));
            say(sl, SAYINGS[rnd.nextInt(SAYINGS.length)]);
        }

        // quietly leaves when nobody is looking
        int lifetime = 20 * (follower ? 200 : 80);
        if (life > lifetime && !anyoneLooking(sl)) {
            sl.getServer().getPlayerList().broadcastSystemMessage(
                    Component.translatable("multiplayer.player.left", Component.literal(mimicName)).withStyle(ChatFormatting.YELLOW), false);
            discard();
        }
    }

    private boolean anyoneLooking(ServerLevel sl) {
        for (ServerPlayer p : sl.players()) {
            if (distanceTo(p) > 64) continue;
            var to = getEyePosition().subtract(p.getEyePosition()).normalize();
            if (p.getViewVector(1f).dot(to) > 0.6 && p.hasLineOfSight(this)) return true;
        }
        return false;
    }

    public void sayPublic(String msg) { if (level() instanceof ServerLevel sl) say(sl, msg); }

    private void say(ServerLevel sl, String msg) {
        sl.getServer().getPlayerList().broadcastSystemMessage(
                Component.translatable("chat.type.text", Component.literal(mimicName), Component.literal(msg)), false);
    }

    private void startReveal(ServerPlayer p) {
        revealTicks = 0; revealTarget = p;
        getNavigation().stop();
        String[] lines = customLines != null ? customLines : LINES;
        say((ServerLevel) level(), lines[rnd.nextInt(lines.length)]);
        playSound(SoundEvents.ENDERMAN_STARE, 1.5f, 0.6f);
    }

    private void tickReveal(ServerLevel sl) {
        revealTicks++;
        getNavigation().stop();
        if (revealTarget != null) getLookControl().setLookAt(revealTarget, 90f, 90f);
        // the disguise tears itself apart
        setDeltaMovement(0, getDeltaMovement().y, 0);
        setYRot(getYRot() + (rnd.nextFloat() - 0.5f) * 40f);
        if (revealTicks == 17) setSkin(REVEAL_SKIN);
        if (revealTicks % 4 == 0) sl.sendParticles(ParticleTypes.SMOKE, getX(), getY() + 1, getZ(), 6, 0.3, 0.6, 0.3, 0.02);
        if (revealTicks >= 34) {
            sl.sendParticles(ParticleTypes.POOF, getX(), getY() + 1, getZ(), 30, 0.4, 0.8, 0.4, 0.03);
            double x = getX(), y = getY(), z = getZ();
            discard();
            FriendDirector.INSTANCE.startChaseAt(sl, x, y, z, revealTarget);
        }
    }

    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public boolean isPushable() { return false; }
}
