package dev.dante.friend.client;

import dev.dante.friend.Compat;
import dev.dante.friend.FriendEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

public final class FriendHud {
    private FriendHud() {}
    private static ResourceLocation tex(String n) { return Compat.rl("friend", "textures/gui/" + n + ".png"); }

    public static void render(GuiGraphics g, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.options.hideGui) return;
        FriendEntity best = null; double bd = 1e18;
        for (FriendEntity f : mc.level.getEntitiesOfClass(FriendEntity.class, mc.player.getBoundingBox().inflate(160))) {
            double d = f.distanceToSqr(mc.player);
            if (d < bd) { bd = d; best = f; }
        }
        if (best == null) return;
        int phase = best.getPhase();
        String bar = phase == 2 ? "bar_chase" : phase == 1 ? "bar_stalking" : "bar_watching";
        String face = phase == 2 ? "face_chase" : phase == 1 ? "face_stalking" : "face_watching";
        g.blit(tex("bar_empty"), w / 2 - 100, 6, 0, 0, 200, 27, 200, 27);
        g.blit(tex(bar), w / 2 - 100, 6, 0, 0, 200, 27, 200, 27);
        g.blit(tex(face), w / 2 - 12, 34, 0, 0, 25, 25, 25, 25);
        if (best.getAction() == FriendEntity.ACT_JUMPSCARE && bd < 100) {
            g.fill(0, 0, w, h, 0xFF000000);
            int s = Math.min(w, h);
            g.blit(tex("face_chase"), (w - s) / 2, (h - s) / 2, s, s, 0, 0, 25, 25, 25, 25);
        }
    }
}
