package dev.dante.friend.client;

import dev.dante.friend.Compat;
import dev.dante.friend.FriendEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

public final class FriendHud {
    private FriendHud() {}
    private static ResourceLocation tex(String n) { return Compat.rl("friend", "textures/gui/" + n + ".png"); }

    public static void render(GuiGraphics g, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.options.hideGui) return;
        FriendEntity best = null; double bd = 1e18;
        for (FriendEntity f : mc.level.getEntitiesOfClass(FriendEntity.class, mc.player.getBoundingBox().inflate(160))) {
            double d = f.distanceToSqr(mc.player);
            if (d < bd) { bd = d; best = f; }
        }
        if (mc.level.dimension() != net.minecraft.world.level.Level.OVERWORLD && best == null) return;
        int phase;
        if (best != null) phase = best.getPhase();
        else {
            long day = (mc.level.getDayTime() / 24000L) % 6;
            phase = day == 0 ? 3 : day == 1 ? 0 : day == 5 ? 2 : 1;
        }
        String bar = phase == 2 ? "bar_chase" : phase == 1 ? "bar_stalking" : phase == 3 ? "bar_empty" : "bar_watching";
        String face = phase == 2 ? "face_chase" : phase == 1 ? "face_stalking" : "face_watching";
        g.blit(tex("bar_empty"), w / 2 - 100, 6, 0, 0, 200, 27, 200, 27);
        g.blit(tex(bar), w / 2 - 100, 6, 0, 0, 200, 27, 200, 27);
        g.blit(tex(face), w / 2 - 12, 34, 0, 0, 25, 25, 25, 25);
    }
}
