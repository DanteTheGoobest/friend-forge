package dev.dante.friend;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.Level;

/** Version-specific synched data for the Mimic (skin number). */
public abstract class MimicBase extends PathfinderMob {
    private static final EntityDataAccessor<Integer> SKIN = SynchedEntityData.defineId(MimicBase.class, EntityDataSerializers.INT);

    protected MimicBase(EntityType<? extends PathfinderMob> t, Level l) { super(t, l); }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(SKIN, 0);
    }

    public int getSkin() { return this.entityData.get(SKIN); }
    public void setSkin(int s) { this.entityData.set(SKIN, s); }
}
