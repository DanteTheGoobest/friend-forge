package dev.dante.friend;
import net.minecraft.resources.ResourceLocation;
public final class Compat {
    private Compat() {}
    public static ResourceLocation rl(String ns, String path) { return new ResourceLocation(ns, path); }
    public static boolean isGlassBlock(net.minecraft.world.level.block.state.BlockState s) { return s.getBlock() instanceof net.minecraft.world.level.block.AbstractGlassBlock; }
}
