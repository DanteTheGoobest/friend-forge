package dev.dante.friend.client;

import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.common.MinecraftForge;

public final class HudHook {
    private HudHook() {}
    public static void register() {
        MinecraftForge.EVENT_BUS.addListener((RenderGuiEvent.Post e) ->
                FriendHud.render(e.getGuiGraphics(), e.getWindow().getGuiScaledWidth(), e.getWindow().getGuiScaledHeight()));
    }
}
