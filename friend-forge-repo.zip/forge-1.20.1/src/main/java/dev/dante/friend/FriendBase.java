package dev.dante.friend;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.Level;

/** Version-specific synched-data plumbing. */
public abstract class FriendBase extends PathfinderMob {
    private static final EntityDataAccessor<Integer> PHASE = SynchedEntityData.defineId(FriendBase.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> ACTION = SynchedEntityData.defineId(FriendBase.class, EntityDataSerializers.INT);

    protected FriendBase(EntityType<? extends PathfinderMob> t, Level l) { super(t, l); }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(PHASE, 0);
        this.entityData.define(ACTION, 0);
    }

    public int getPhase() { return this.entityData.get(PHASE); }
    protected void rawPhase(int p) { this.entityData.set(PHASE, p); }
    public int getAction() { return this.entityData.get(ACTION); }
    public void setAction(int a) { this.entityData.set(ACTION, a); }
}
