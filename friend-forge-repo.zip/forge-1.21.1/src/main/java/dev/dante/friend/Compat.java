package dev.dante.friend;
import net.minecraft.resources.ResourceLocation;
public final class Compat {
    private Compat() {}
    public static ResourceLocation rl(String ns, String path) { return ResourceLocation.fromNamespaceAndPath(ns, path); }
}
