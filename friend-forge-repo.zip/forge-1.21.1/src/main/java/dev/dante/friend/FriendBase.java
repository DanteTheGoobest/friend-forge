package dev.dante.friend;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.AnimationState;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

/** Version-specific plumbing: synched data + GeckoLib package layout. */
public abstract class FriendBase extends PathfinderMob implements GeoEntity {
    private static final EntityDataAccessor<Integer> PHASE = SynchedEntityData.defineId(FriendBase.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> ACTION = SynchedEntityData.defineId(FriendBase.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> CRAWL = SynchedEntityData.defineId(FriendBase.class, EntityDataSerializers.BOOLEAN);
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    protected FriendBase(EntityType<? extends PathfinderMob> t, Level l) { super(t, l); }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder b) {
        super.defineSynchedData(b);
        b.define(PHASE, 0);
        b.define(ACTION, 0);
        b.define(CRAWL, false);
    }

    public boolean isCrawling() { return this.entityData.get(CRAWL); }
    public void setCrawling(boolean c) {
        if (c != isCrawling()) { this.entityData.set(CRAWL, c); refreshDimensions(); }
    }
    @Override public void onSyncedDataUpdated(EntityDataAccessor<?> a) {
        super.onSyncedDataUpdated(a);
        if (a == CRAWL) refreshDimensions();
    }
    @Override
    public net.minecraft.world.entity.EntityDimensions getDefaultDimensions(net.minecraft.world.entity.Pose p) {
        return isCrawling() ? net.minecraft.world.entity.EntityDimensions.scalable(0.8f, 0.9f) : super.getDefaultDimensions(p);
    }

    public int getPhase() { return this.entityData.get(PHASE); }
    protected void rawPhase(int p) { this.entityData.set(PHASE, p); }
    public int getAction() { return this.entityData.get(ACTION); }
    public void setAction(int a) { this.entityData.set(ACTION, a); }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar c) {
        c.add(new AnimationController<>(this, "main", 5, this::predicate));
    }

    private <E extends GeoEntity> PlayState predicate(AnimationState<E> s) {
        int phase = getPhase(), act = getAction();
        String a;
        boolean once = false;
        if (act == FriendEntity.ACT_JUMPSCARE) { a = "jumpscare"; once = true; }
        else if (act == FriendEntity.ACT_ROAR) { a = "roar_scream"; once = true; }
        else if (act == FriendEntity.ACT_TAP) a = "tap";
        else if (isCrawling()) a = "crawl";
        else if (s.isMoving()) a = phase == FriendEntity.CHASE ? "run" : phase == FriendEntity.STALK ? "stalk_jerk" : "walk";
        else a = (phase == FriendEntity.WATCH || phase == FriendEntity.APPEAR) ? "watch_idle" : "idle_creep";
        RawAnimation r = once ? RawAnimation.begin().thenPlayAndHold("animation.friend." + a)
                              : RawAnimation.begin().thenLoop("animation.friend." + a);
        return s.setAndContinue(r);
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
